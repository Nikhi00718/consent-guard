"""Redaction renderers."""
